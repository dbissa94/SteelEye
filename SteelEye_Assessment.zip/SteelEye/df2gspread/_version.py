#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author: Eduard Trott
# @Date:   2015-09-15 08:57:35
# @Email:  etrott@redhat.com
# @Last modified by:   etrott
# @Last Modified time: 2016-03-08 12:36:30


version_info = ('1', '0', '4')
__version__ = '.'.join(version_info[0:3])  # + '-' + version_info[3]
